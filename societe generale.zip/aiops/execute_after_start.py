# -*- coding: utf-8 -*-

# Everything in the execute func will be executed after all UI's started
# This can be used to start custom scripts, or other automation processes, like for making preconfigured setup


def execute():
    # import thlib.environment as thenv
    # thenv.tc().execute_custom_script('batch/batch_dispatcher', project='dolly3d')
    pass
