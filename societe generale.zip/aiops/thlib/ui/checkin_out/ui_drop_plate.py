# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'checkin_out\ui_drop_plate.ui'
#
# Created: Mon Oct 14 11:50:09 2019
#      by: pyside-uic 0.2.15 running on PySide 1.2.4
#
# WARNING! All changes made in this file will be lost!

from thlib.side.Qt import QtWidgets as QtGui
from thlib.side.Qt import QtGui as Qt4Gui
from thlib.side.Qt import QtCore

class Ui_dropPlate(object):
    def setupUi(self, dropPlate):
        dropPlate.setObjectName("dropPlate")
        self.gridLayout = QtGui.QGridLayout(dropPlate)
        self.gridLayout.setContentsMargins(4, 4, 4, 6)
        self.gridLayout.setHorizontalSpacing(4)
        self.gridLayout.setObjectName("gridLayout")
        self.dropTreeWidget = QtGui.QTreeWidget(dropPlate)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Ignored, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.dropTreeWidget.sizePolicy().hasHeightForWidth())
        self.dropTreeWidget.setSizePolicy(sizePolicy)
        self.dropTreeWidget.setStyleSheet("QTreeView::item {\n"
"    padding: 2px;\n"
"}\n"
"\n"
"QTreeView::item:selected:active{\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(82, 133, 166, 255), stop:1 rgba(82, 133, 166, 255));\n"
"    border: 1px solid transparent;\n"
"}\n"
"QTreeView::item:selected:!active {\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(82, 133, 166, 255), stop:1 rgba(82, 133, 166, 255));\n"
"    border: 1px solid transparent;\n"
"}\n"
"")
        self.dropTreeWidget.setEditTriggers(QtGui.QAbstractItemView.AllEditTriggers)
        self.dropTreeWidget.setTabKeyNavigation(True)
        self.dropTreeWidget.setAlternatingRowColors(True)
        self.dropTreeWidget.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.dropTreeWidget.setTextElideMode(QtCore.Qt.ElideMiddle)
        self.dropTreeWidget.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.dropTreeWidget.setIndentation(20)
        self.dropTreeWidget.setRootIsDecorated(True)
        self.dropTreeWidget.setUniformRowHeights(True)
        self.dropTreeWidget.setItemsExpandable(True)
        self.dropTreeWidget.setAllColumnsShowFocus(True)
        self.dropTreeWidget.setWordWrap(True)
        self.dropTreeWidget.setHeaderHidden(False)
        self.dropTreeWidget.setObjectName("dropTreeWidget")
        self.dropTreeWidget.header().setCascadingSectionResizes(True)
        self.gridLayout.addWidget(self.dropTreeWidget, 0, 0, 1, 5)
        self.progressBarLayout = QtGui.QHBoxLayout()
        self.progressBarLayout.setSpacing(0)
        self.progressBarLayout.setObjectName("progressBarLayout")
        self.gridLayout.addLayout(self.progressBarLayout, 1, 0, 1, 5)
        self.filterLineEdit = QtGui.QLineEdit(dropPlate)
        self.filterLineEdit.setEnabled(False)
        self.filterLineEdit.setStyleSheet("QLineEdit {\n"
"    border: 0px;\n"
"    border-radius: 8px;\n"
"    show-decoration-selected: 1;\n"
"    padding: 0px 8px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(255, 255, 255, 64), stop:1 rgba(255, 255, 255, 0));\n"
"    background-position: bottom left;\n"
"    background-image: url(\":/ui_check/gliph/search_16.png\");\n"
"    background-repeat: fixed;\n"
"    selection-background-color: darkgray;\n"
"    padding-left: 15px;\n"
"}\n"
"QLineEdit:hover{\n"
"    color: white;\n"
"    background-image: url(\":/ui_check/gliph/searchHover_16.png\");\n"
"}")
        self.filterLineEdit.setObjectName("filterLineEdit")
        self.gridLayout.addWidget(self.filterLineEdit, 2, 0, 1, 1)
        self.expandingLayout = QtGui.QHBoxLayout()
        self.expandingLayout.setObjectName("expandingLayout")
        self.enableFilterCheckBox = QtGui.QCheckBox(dropPlate)
        self.enableFilterCheckBox.setChecked(False)
        self.enableFilterCheckBox.setObjectName("enableFilterCheckBox")
        self.expandingLayout.addWidget(self.enableFilterCheckBox)
        self.filterComboBox = QtGui.QComboBox(dropPlate)
        self.filterComboBox.setEnabled(False)
        self.filterComboBox.setObjectName("filterComboBox")
        self.filterComboBox.addItem("")
        self.filterComboBox.addItem("")
        self.expandingLayout.addWidget(self.filterComboBox)
        self.groupCheckinCheckBox = QtGui.QCheckBox(dropPlate)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupCheckinCheckBox.sizePolicy().hasHeightForWidth())
        self.groupCheckinCheckBox.setSizePolicy(sizePolicy)
        self.groupCheckinCheckBox.setObjectName("groupCheckinCheckBox")
        self.expandingLayout.addWidget(self.groupCheckinCheckBox)
        self.keepFileNameCheckBox = QtGui.QCheckBox(dropPlate)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.keepFileNameCheckBox.sizePolicy().hasHeightForWidth())
        self.keepFileNameCheckBox.setSizePolicy(sizePolicy)
        self.keepFileNameCheckBox.setObjectName("keepFileNameCheckBox")
        self.expandingLayout.addWidget(self.keepFileNameCheckBox)
        self.includeSubfoldersCheckBox = QtGui.QCheckBox(dropPlate)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.includeSubfoldersCheckBox.sizePolicy().hasHeightForWidth())
        self.includeSubfoldersCheckBox.setSizePolicy(sizePolicy)
        self.includeSubfoldersCheckBox.setObjectName("includeSubfoldersCheckBox")
        self.expandingLayout.addWidget(self.includeSubfoldersCheckBox)
        self.gridLayout.addLayout(self.expandingLayout, 2, 1, 1, 2)
        self.configPushButton = QtGui.QToolButton(dropPlate)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.configPushButton.sizePolicy().hasHeightForWidth())
        self.configPushButton.setSizePolicy(sizePolicy)
        self.configPushButton.setMinimumSize(QtCore.QSize(24, 24))
        self.configPushButton.setMaximumSize(QtCore.QSize(24, 24))
        self.configPushButton.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)
        self.configPushButton.setAutoRaise(True)
        self.configPushButton.setObjectName("configPushButton")
        self.gridLayout.addWidget(self.configPushButton, 2, 3, 1, 1)
        self.clearPushButton = QtGui.QToolButton(dropPlate)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.clearPushButton.sizePolicy().hasHeightForWidth())
        self.clearPushButton.setSizePolicy(sizePolicy)
        self.clearPushButton.setMinimumSize(QtCore.QSize(24, 24))
        self.clearPushButton.setMaximumSize(QtCore.QSize(24, 24))
        self.clearPushButton.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)
        self.clearPushButton.setAutoRaise(True)
        self.clearPushButton.setObjectName("clearPushButton")
        self.gridLayout.addWidget(self.clearPushButton, 2, 4, 1, 1)
        self.gridLayout.setRowStretch(0, 1)

        self.retranslateUi(dropPlate)
        QtCore.QObject.connect(self.enableFilterCheckBox, QtCore.SIGNAL("toggled(bool)"), self.filterComboBox.setEnabled)
        QtCore.QObject.connect(self.enableFilterCheckBox, QtCore.SIGNAL("toggled(bool)"), self.filterLineEdit.setEnabled)
        QtCore.QMetaObject.connectSlotsByName(dropPlate)

    def retranslateUi(self, dropPlate):
        dropPlate.setWindowTitle(u"Form")
        self.dropTreeWidget.setSortingEnabled(True)
        self.dropTreeWidget.headerItem().setText(0, u"File Name")
        self.dropTreeWidget.headerItem().setText(1, u"Range/Tiles/Layer")
        self.dropTreeWidget.headerItem().setText(2, u"Class/Ext")
        self.dropTreeWidget.headerItem().setText(3, u"Type")
        self.dropTreeWidget.headerItem().setText(4, u"File Path")
        self.enableFilterCheckBox.setText(u"Filter:")
        self.filterComboBox.setItemText(0, u"By Extension")
        self.filterComboBox.setItemText(1, u"By Filename")
        self.groupCheckinCheckBox.setText(u"Group Checkin")
        self.keepFileNameCheckBox.setText(u"Keep Filename")
        self.includeSubfoldersCheckBox.setText(u"Include Subfolders")

