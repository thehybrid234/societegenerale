# timelapsed-py
A simple python module that makes it easy to support fuzzy timestamps (e.g. "4 minutes ago" or "1 day ago")
