__version__ = "0.1.1"
from .tasks import Task, ProcessTask, MultiTask, MultiProcessTask
from .engine import Engine
