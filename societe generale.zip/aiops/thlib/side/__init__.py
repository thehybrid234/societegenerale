# This init will let you access all lib.side just as they were in site-packages

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))


__author__ = 'Krivospitskiy Alexey'

